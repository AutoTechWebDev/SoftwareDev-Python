Choose Your Own Adventure!

Game created in Python

Lost inside the Catacombs of Paris you must find your way out. Be wary of the creatures that lurk within! Safe travels, traveller! 
